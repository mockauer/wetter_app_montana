<?php
include("date.php");
 $handle = sqlite_open("wetter.sqt");
$res = sqlite_query($handle, "SELECT * FROM wetter WHERE datum=date('now')");

   while($dsatz = sqlite_fetch_array($res, SQLITE_ASSOC))
   {
      echo "<b>Tempatur Carcas am ". date_german($dsatz["datum"]) ."</b><br/>"
         . "Tag: " .$dsatz["tag"] . "�C<br/> "
         . "Nacht: ".$dsatz["nacht"] . "�C<br/> "
         . "<img src='img/".$dsatz["wetter"].".jpg' /><br />";
		 
	 
   }


   sqlite_close($handle);




?>